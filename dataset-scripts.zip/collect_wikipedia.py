"""Human-written carriers from Wikipedia (CC BY-SA - cite in the datasheet). Resumable.
  python collect_wikipedia.py --n 800"""
import json, re, time, argparse, pathlib, requests
API = "https://en.wikipedia.org/w/api.php"; HDR = {"User-Agent": "CPI-AgentTrapScanner/0.1 (student project)"}
ap = argparse.ArgumentParser(); ap.add_argument("--n", type=int, default=800); a = ap.parse_args()
f = pathlib.Path("carriers/real/wikipedia.jsonl"); f.parent.mkdir(parents=True, exist_ok=True)
have = sum(1 for _ in open(f, encoding="utf-8")) if f.exists() else 0
n = have
while n < a.n:
    r = requests.get(API, headers=HDR, timeout=30, params=dict(action="query", format="json", generator="random", grnnamespace=0,
        grnlimit=20, prop="extracts", explaintext=1, exlimit="max")).json()
    for p in r.get("query", {}).get("pages", {}).values():
        t = re.sub(r"\n==+[^=]+==+\n", "\n\n", p.get("extract", "")); t = re.sub(r"\n{3,}", "\n\n", t).strip()
        paras = [x for x in t.split("\n\n") if len(x.split()) > 25][:8]
        text = "\n\n".join(paras)
        if len(paras) < 4 or not (150 <= len(text.split()) <= 700): continue
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(id=f"wiki-{p['pageid']}", kind="web", source="wikipedia-human", topic=p["title"], text=text), ensure_ascii=False) + "\n")
        n += 1
        if n >= a.n: break
    print(n, "saved"); time.sleep(1)
