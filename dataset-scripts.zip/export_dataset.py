"""Package the corpus for the person who trains the model -> export/
  train.jsonl val.jsonl test.jsonl                 (in-distribution styles)
  test_ood.jsonl   (held-out style: authority_notice)   evasion_test.jsonl (obfuscated: bipia_obfuscated)
  each also as *_full.jsonl with all metadata + raw HTML.  Slim files have: id, text, label.
  train.jsonl is the ONLY file to train on."""
import json, pathlib, collections
rows = [json.loads(l) for l in open("data/corpus.jsonl", encoding="utf-8")]
out = pathlib.Path("export"); out.mkdir(exist_ok=True)
twin_ids = lambda style: {r["carrier_id"] for r in rows if r["label"] == 1 and r["style"] == style}
ood, evas = twin_ids("authority_notice"), twin_ids("bipia_obfuscated")
def part(r):
    if r["split"] != "test": return r["split"]
    if r["carrier_id"] in evas: return "evasion_test"
    if r["carrier_id"] in ood: return "test_ood"
    return "test"
groups = collections.defaultdict(list)
for r in rows: groups[part(r)].append(r)
slim = ("id", "text", "label")
for name, rs in groups.items():
    with open(out / f"{name}.jsonl", "w", encoding="utf-8") as f, open(out / f"{name}_full.jsonl", "w", encoding="utf-8") as g:
        for r in rs:
            f.write(json.dumps({k: r[k] for k in slim}, ensure_ascii=False) + "\n"); g.write(json.dumps(r, ensure_ascii=False) + "\n")
lines = ["# Agent Trap Scanner dataset - datasheet", "", "Task: binary - does the text contain a hidden/indirect prompt injection (1) or not (0).", "",
         "| file | clean | injected |", "|---|---|---|"] + [f"| {n}.jsonl | {sum(r['label']==0 for r in rs)} | {sum(r['label']==1 for r in rs)} |" for n, rs in sorted(groups.items())]
srcs = collections.Counter(r["carrier_source"] for r in rows if r["label"] == 0); atk = collections.Counter(r["attack_source"] for r in rows if r["label"] == 1)
lines += ["", "Carrier sources (clean docs): " + ", ".join(f"{k}={v}" for k, v in srcs.items()), "Attack sources (injected docs): " + ", ".join(f"{k}={v}" for k, v in atk.items()),
          "", "Rules: train ONLY on train.jsonl (val.jsonl for tuning). test_ood and evasion_test use attack styles never seen in train. No injection string appears in more than one split.",
          "Licences: BIPIA MIT; Open-Prompt-Injection, InjecAgent, garak per their repos; Wikipedia text CC BY-SA. Fill in LLM providers/models used for generated carriers.",
          "Known gaps: English only; text carriers (no images/PDF); injection goals reused across styles."]
open(out / "DATASHEET.md", "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("\n".join(lines[4:4 + len(groups) + 2]))
