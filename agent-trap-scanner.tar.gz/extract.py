"""Candidate-text extraction: returns everything a human reader would NOT see as well as what they would,
in document order. This is what the detector scores. For plain-text carriers it is the identity."""
import re
from bs4 import BeautifulSoup, Comment, NavigableString, Tag

HIDDEN_STYLE = re.compile(r"display\s*:\s*none|visibility\s*:\s*hidden|font-size\s*:\s*0|opacity\s*:\s*0|"
                          r"color\s*:\s*(#fff(fff)?|white)\b|left\s*:\s*-\d{3,}px", re.I)
ATTRS = ("aria-label", "alt", "title", "placeholder", "data-description")

def extract_segments(html: str):
    """-> list of (channel, text). channels: visible, css_hidden, comment, attr"""
    soup = BeautifulSoup(html, "html.parser"); segs = []
    def walk(node, hidden):
        for ch in node.children:
            if isinstance(ch, Comment):
                t = str(ch).strip()
                if t: segs.append(("comment", t))
            elif isinstance(ch, NavigableString):
                t = " ".join(str(ch).split())
                if t: segs.append(("css_hidden" if hidden else "visible", t))
            elif isinstance(ch, Tag):
                if ch.name in ("script", "style"): continue
                for a in ATTRS:
                    v = ch.get(a)
                    if v and v.strip(): segs.append(("attr", v.strip()))
                h = hidden or bool(HIDDEN_STYLE.search(ch.get("style", ""))) or ch.has_attr("hidden")
                walk(ch, h)
    walk(soup, False)
    return segs

def extract_text(raw: str, kind: str) -> str:
    return raw if kind != "web" else "\n".join(t for _, t in extract_segments(raw))
