# Agent Trap Scanner - corpus + eval harness
    git clone Open-Prompt-Injection, InjecAgent, garak into raw/   (already done)
    python build_corpus.py        -> data/corpus.jsonl  (paired clean/injected docs)
    python evaluate.py            -> runs keyword baseline; plug any detector(list[str])->list[float] into evaluate()
Files: attacks.py (styles), carriers.py, build_corpus.py, extract.py (hidden-text extraction), evaluate.py.
Held out: style `authority_notice` appears only in test (ood_style=True). Exact injection strings never cross splits.
Caveat: injection *content* (InjecAgent goals) is reused across styles, so OOD tests form, not goal.

## BIPIA integration (raw/BIPIA, MIT licence)
Attacks: text -> `bipia_text` (non-obfuscated categories), code -> `bipia_code`, obfuscated categories -> `bipia_obfuscated` (test-only evasion set).
BIPIA's train/test attack categories are disjoint and kept that way. Carriers: 100 real emails + 300 tables (WebQA/Summarization need NewsQA/arXiv downloads - not done).
Note: with BIPIA carriers only there are no web/HTML docs, so hiding methods and hard negatives are unused until real web carriers are added.
